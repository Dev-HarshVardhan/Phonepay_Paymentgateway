<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thanku</title>
</head>

<body>
    <style>
        * {
            box-sizing: border-box;
            /* outline:1px solid ;*/
        }

        body {
            background: #ffffff;
            background: linear-gradient(to bottom, #ffffff 0%, #e1e8ed 100%);
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffff', endColorstr='#e1e8ed', GradientType=0);
            margin: 0;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }

        .wrapper-1 {
            width: 100%;
            height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .wrapper-2 {
            padding: 30px;
            text-align: center;
        }

        h1 {
            font-family: 'Kaushan Script', cursive;
            font-size: 4em;
            letter-spacing: 3px;
            color: #0d6efd;
            margin: 0;
            margin-bottom: 20px;
        }

        .top-wrap {
            text-align: center;
            background: #0d6efd;
            color: #fff;
            line-height: 10px;
        }

        .wrapper-2 p {
            margin: 0;
            font-size: 1.3em;
            color: #222;
            font-family: 'Source Sans Pro', sans-serif;
            letter-spacing: 1px;
        }

        .go-home {
            color: #fff;
            background: #0d6efd;
            border: none;
            padding: 10px 50px;
            margin: 30px 0;
            border-radius: 30px;
            text-transform: capitalize;
            box-shadow: 0 10px 16px 1px rgba(174, 199, 251, 1);
            text-decoration: none;
        }

        .footer-like {
            margin-top: auto;
            background: #D7E6FE;
            padding: 6px;
            text-align: center;
        }

        .footer-sec {
            gap: 27px;
            display: flex;
            justify-content: space-between;
            margin-top: 40px;
            /*width: 800px;*/
            margin: auto;
        }

        .wrapper-1 {
            margin-bottom: 40px !important;
        }

        .visit-home {
            width: 50%;
            text-align: center;
            box-shadow: 0 0 8px 1px #b1b1b1;
        }

        .social-link {
            width: 50%;
            text-align: center;
            box-shadow: 0 0 8px 1px #b1b1b1;
        }

        .visit-home {
            width: 50%;
            text-align: center;
        }

        .wrapper-1 {
            margin-bottom: 40px;
        }

        .footer-like p {
            margin: 0;
            padding: 4px;
            color: #060606;
            font-family: 'Source Sans Pro', sans-serif;
            letter-spacing: 1px;
        }

        .footer-like p a {
            text-decoration: none;
            color: #0d6efd;
            font-weight: 600;
        }

        .bg a i {
            color: #0d6efd;
        }

        .bg a {
            height: 48px;
            width: 48px;
            font-size: 18px;
            line-height: 48px;
            /* display: block; */
            color: white;
            text-decoration: none;
            margin: 10px;
        }

        i.fa-brands {
            /* padding-top: 20; */
            font-size: 41px;
        }

        a.my_btn {
            background: #0d6efd;
            text-decoration: none;
            padding: 11px 35px;
            font-size: 20px;
            color: wheat;
            border-radius: 3px;
        }

        @media (min-width:360px) {
            h1 {
                font-size: 3.5em;
            }

            .go-home {
                margin-bottom: 20px;
            }
        }

        @media (min-width:600px) {
            .content {
                max-width: 1000px;
                margin: 0 auto;
            }

            .wrapper-1 {
                height: initial;
                /*max-width: 800px;*/
                margin: 0 auto;
                margin-top: 20px;
                box-shadow: 4px 8px 10px 8px rgba(88, 146, 255, 0.2);
            }

            .home-b {
                margin-top: 30px;
            }

        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
    <div class=content>

        <div class="wrapper-1">
            <div class="top-wrap">
                <h2>Phone pay Payment Gateway IN PHP</h2>
            </div>
            <div class="wrapper-2">
                <h1>Thank you !</h1>
                <p>Thanks for subscribing.</p>
                <p>You should receive a confirmation  soon. </p>
                <div class="home-b">
                    <!--<a href="https://modesigns.in/" class="go-home">-->
                    <!--Go to Home-->
                    <!--</a>-->
                </div>
            </div>
        </div>

        <div class="footer-sec">
            <div class="social-link">
                <div class="content">
                    <h2>Like & Share</h2>
                </div>
                <div class="content">
                    <div class='bg'>
                        <a href="#!" target="_blank"><i class="fa-brands fa-square-facebook"></i>
                        </a>

                        <a href="#!" target="_blank"><i class="fa-brands fa-linkedin"></i>
                        </a>
                        <a href="#!" target="_blank">
                            <i class="fa-brands fa-square-instagram"></i>
                        </a>
                    </div>
                </div>
            </div>
            <div class="visit-home">
                <div class="content">
                    <h2>Visit Our Website</h2>
                </div>
                <div class="content">
                    <div class='btn btn-success'>
                        <a href='http://localhost/paymentgateway/phonepe/' class='my_btn'>Let's Go</a>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <link href="https://fonts.googleapis.com/css?family=Kaushan+Script|Source+Sans+Pro" rel="stylesheet">

</body>

</html>