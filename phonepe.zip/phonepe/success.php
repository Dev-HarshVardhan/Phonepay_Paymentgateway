<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  
</head>
<body>
  
</body>
</html>
<?php 
// require_once("admin/db_connect.php");
  // Display the POST data for debugging
//   echo '<pre>';
//   print_r($_POST);
//   echo '</pre>';

  $transactionId = $_POST['transactionId'];

  // Check if the required fields are in the POST data
  if (isset($_POST['code']) && $_POST['code'] == 'PAYMENT_SUCCESS' ) {
      
      // // Create the query to update the payment_status
      // $sql = "UPDATE payment SET payment_status = 'success' WHERE order_id ='$transactionId'";
      // $result=mysqli_query($conn,$sql);

      // Execute the query
      // if ($result == TRUE) {
            header("location:thanku.php");
      // } else {
      //     echo "Error updating payment status: " . $conn->error;
      // }
  } else {
      echo "Payment Failed ";
  }

  // Close the database connection
//   $conn->close();
?>
